import java.util.Objects;
import java.util.Scanner;

public class ChatBot {
    private int id_chat = 0;
    private String nome;
    private String tipo;

    public ChatBot(String nome, String tipo){
        this.id_chat = id_chat+1;
        this.nome = nome;
        this.tipo = tipo;
    }

    //esse método é uma simulação do Chatbot, com apenas 2 perguntas (porém quando for adicionado a API da IBM Cloud, ele será verdadeiramente, inteligente)
    public static String responderPerguntas(String pergunta){
        switch (pergunta){
            case "O que é ecoturismo?":
                return "Ecoturismo é uma forma de turismo voltado para a apreciação de ambientes naturais.";
            case "Como posso me inscrever em uma atividade?":
                return "Para se inscrever em uma atividade, você deve estar logado e acessar a página da atividade desejada.";
            default:
                return "Desculpe, não entendi a pergunta.";
        }
    }

    //esse método simula uma conversa com o Chatbot, usando um próprio método da classe
    public void simularConversa(){
        Scanner sc = new Scanner(System.in);
        String pergunta1 = "O que é ecoturismo?";
        String pergunta2 = "Como posso me inscrever em uma atividade?";

        System.out.println("Qual sua dúvida?");
        System.out.println("Perguntas: 1- O que é ecoturismo? 2 - Como posso me inscrever em uma atividade? ");
        int pergunta = sc.nextInt();
        if (pergunta == 1){
            String resposta1 = responderPerguntas(pergunta1);
            System.out.println("Chatbot: " + resposta1);
        }else if(pergunta == 2){
            String resposta2 = responderPerguntas(pergunta2);
            System.out.println("Chatbot: " + resposta2);
        }else{
            String resposta3 = responderPerguntas("Qual a cor do ceu?");
            System.out.println("Chatbot: "+resposta3);
        }
    }

    //com a API será adicionado ao java para dar suporte
    public void fornecerSuporte(){}

//  encapsulamento

    public int getId_chat() {
        return id_chat;
    }

    public void setId_chat(int id_chat) {
        this.id_chat = id_chat;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String pergunta1 = scanner.nextLine();
        new ChatBot("Ecobot", "suporte");
        System.out.println("Ecobot: "+ responderPerguntas(pergunta1));
    }
}
