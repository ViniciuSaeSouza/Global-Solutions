public class Pessoa {
//  super classe
    protected int id = 0;
    protected String nome;
    protected String email;
    protected String senha;

    public Pessoa(int id, String nome,String email, String senha){
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    //esse método cadastra um usuario, só foi inicializado, pois ainda precisa do banco de dados. Depois será desenvolvido por completo.
    //para ser possivel diferenciar os usuarios(classes filhas)
    public void cadastrar(String nome, String email, String senha ){
        this.id +=1;
        new Pessoa(this.id, nome, email, senha);
    }
    //esse método faz o login de um usuario, só foi inicializado, pois ainda precisa do banco de dados. Depois será desenvolvido por completo.
    public void fazerLogin(){
        // nesse metodo iria puxar do banco de dados, já com a especificação de usuario
    }
    //esse método exibe o perfil do usuario
    public void exibirPerfil(){
        System.out.println("Id: "+ this.id +" | Nome: "+this.nome+" | E-mail: "+this.email);
    }

//  encapsulamento
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
