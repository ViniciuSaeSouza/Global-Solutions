import java.util.Date;
import java.util.Objects;
import java.util.Scanner;

public class Menu {
    private ChatBot chatBot;
    private Portal portal;
    // construtor que inicializa os objetos chatbot e portal
    Menu(){
        portal = new Portal();
        chatBot = new ChatBot("EcoBot","Suporte");
    }

    //método que exibe o Menu específico com as opções do Chatbot e Portal
    public void exibirMenu(){
        int opcao = 0;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("0- VOLTAR AO MENU PRINCIPAL | 1- PORTAL | 2-CHATBOT ");
            opcao = sc.nextInt();
            switch (opcao) {
                case 0:
                    System.out.print(" ");
                    break;
                case 1:
                    portal.visualizarPosts();
                    break;
                case 2:
                    chatBot.simularConversa();
                    break;
                default:
                    System.out.println("Essa opção não existe!!");
            }
        }while (opcao != 0);
    }

    //  encapsulamento
    public ChatBot getChatBot() {
        return chatBot;
    }

    public void setChatBot(ChatBot chatBot) {
        this.chatBot = chatBot;
    }

    public Portal getPortal() {
        return portal;
    }

    public void setPortal(Portal portal) {
        this.portal = portal;
    }

}
