import java.util.Date;

public class Portal {
    //o conteudo foi adicionado direto nos atributos, pois nesse momento não é possível puxar do banco de dados
    private int id_post;
    private String titulo = "Sobre nós";
    private String conteudo = "Nosso objetivo é promover atividades de ecoturismo, facilitando o acesso a atividades ecológicas que permitem aos usuários explorar e apreciar a natureza de maneira responsável; apoiar ONG's, dar visibilidade e suporte às ONGs que trabalham com ecoturismo, ajudando-as a alcançar um público maior e gerar mais impacto; fomentar sustentabilidade, incentivar práticas de turismo sustentável, tanto entre os turistas quanto entre os fornecedores de serviços turísticos; educar e conscientizar, utilizar nosso blog para aumentar a conscientização sobre os desafios enfrentados pelos oceanos e a importância de sua preservação; oferecer benefícios exclusivos, proporcionar vantagens financeiras aos nossos usuários através de parcerias com pousadas e hotéis. Tudo isso conectando pessoas a experiências únicas e enriquecedoras, pois a EcoWaves é mais do que uma plataforma de turismo; é um movimento em prol da sustentabilidade e da preservação dos oceanos.\u2028\u2028";
    private Date data_publicacao = new Date(124, 5, 7);

    //esse método adiciona um novo post
    public void adicionarPost(String titulo, String conteudo,Date data_publicacao ){
        this.id_post ++;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.data_publicacao = data_publicacao;
    }
    //esse método edita um post existente
    public void editarPost(String titulo, String conteudo,Date data_publicacao ){
        setTitulo(titulo);
        setConteudo(conteudo);
        setData_publicacao(data_publicacao);
    }
    //esse método exibe um post existente
    public void visualizarPosts(){
        System.out.println(this.titulo.toUpperCase()+ " -> Data de publicação: "+Main.formatarData(this.data_publicacao));
        System.out.println(this.conteudo);
    }

//  encapsulamento
    public int getId_post() {
        return id_post;
    }

    public void setId_post(int id_post) {
        this.id_post = id_post;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Date getData_publicacao() {
        return data_publicacao;
    }

    public void setData_publicacao(Date data_publicacao) {
        this.data_publicacao = data_publicacao;
    }
}
