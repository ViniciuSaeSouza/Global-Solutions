import java.util.Date;

public class Inscricao {
    private int id_inscricao;
    private Date data_inscricao;
    private Voluntario voluntario;
    private Atividades atividades;

    // Construtores sobrecarregados
    public Inscricao(int id, Date data_inscricao,Voluntario voluntario, Atividades atividade){
        this.id_inscricao = id;
        this.voluntario = voluntario;
        this.atividades = atividade;
        this.data_inscricao = data_inscricao;
    }

    public Inscricao(Voluntario voluntario, Atividades atividade) {
        this.voluntario = voluntario;
        this.atividades = atividade;
    } // no caso, esse construtor poderia ser usado se a ONG quisesse apenas ver a relação entre a atividade e a lista de usuarios inscritos

    //esse metodo relaciona uma inscrição com uma atividade, e também verifica se existem vagas para o adicionar o usuario na lista de inscrição dessa atividade
    public static void registrarInscricao(Inscricao inscricao, Atividades atividade) {
        if (atividade.getVagas() > 0) {
            atividade.setVagas(atividade.getVagas() - 1);

            System.out.println("Voluntario: " + inscricao.getVoluntario().nome + " inscrito na atividade: " + inscricao.getAtividades().getNome_atividade() + ". Vagas restantes: " + atividade.getVagas());
        } else {
            System.out.println("Não há vagas disponíveis para esta atividade.");
        }
    }
    //esse método sera incrementado com o banco de dados
    public void cancelarInscricao(){}


//  encapsulamento
    public int getId_inscricao() {
        return id_inscricao;
    }

    public void setId_inscricao(int id_inscricao) {
        this.id_inscricao = id_inscricao;
    }

    public Date getData_inscricao() {
        return data_inscricao;
    }

    public void setData_inscricao(Date data_inscricao) {
        this.data_inscricao = data_inscricao;
    }

    public Voluntario getVoluntario() {
        return voluntario;
    }

    public void setVoluntario(Voluntario voluntario) {
        this.voluntario = voluntario;
    }

    public Atividades getAtividades() {
        return atividades;
    }

    public void setAtividades(Atividades atividades) {
        this.atividades = atividades;
    }
}
