public class Voluntario extends Pessoa{

    public Voluntario(int id_voluntario, String nome, String email, String senha, String descricao){
        super(id_voluntario, nome, email, senha );
    }

    public void visualizarAtividades() {}
    public void seInscreverAtividade() {}

    @Override
    public void exibirPerfil() {
        super.exibirPerfil();
    }
}
