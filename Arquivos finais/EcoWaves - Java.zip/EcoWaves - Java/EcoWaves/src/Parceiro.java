public class Parceiro extends Pessoa{
    private int desconto;
    private String cupom;

//  sobrecarga de métodos construtores.
    public Parceiro(int id_parceiro, String razao_social, String email, String senha){
        super(id_parceiro, razao_social, email, senha );
    }
    public Parceiro(int id_parceiro, String razao_social, String email, String senha , int desconto, String cupom){
        super(id_parceiro, razao_social, email, senha );
        this.desconto = desconto;
        this.cupom = cupom;
    }
    //esse método edita um desconto existente
    public void editarDesconto(int novo_desconto, String novo_cupom){
        this.cupom = novo_cupom;
        this.desconto = novo_desconto;
    }
    //esse método adiciona um desconto para a classe
    public void adicionarDesconto(int desconto, String cupom){
        this.desconto = desconto;
        this.cupom = cupom;
    }
    //esse método exibe o desconto existente na classe
    public void vizualizarDesconto(){
        System.out.println("\nDesconto oferecido por "+super.nome+": "+getDesconto()+"% -> Cupom: "+getCupom());
    }
    //método de sobrescrita para exibir o perfil da "pessoa" e os atributos especificos do "parceiro"
    @Override
    public void exibirPerfil(){
        super.exibirPerfil();
        if(desconto == 0){
            System.out.println("Ainda não foi registrado nenhum cupom.");
        }else{
            System.out.println("\nDesconto oferecido: "+this.desconto+" -> código do cupom: "+this.cupom);
        }
    }

//    encapsulamento
    public int getDesconto() {
        return desconto;
    }

    public void setDesconto(int desconto) {
        this.desconto = desconto;
    }

    public String getCupom() {
        return cupom;
    }

    public void setCupom(String cupom) {
        this.cupom = cupom;
    }
}
