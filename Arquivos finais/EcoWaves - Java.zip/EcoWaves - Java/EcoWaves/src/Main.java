import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        //Registros iniciais, para servir como um banco de dados -> para a execução com o scanner
        // Registro de uma ONG
        ONG ong1 = new ONG(1, "ONG Oceano Limpo", "contato@oceano.org", "ong123", "Proteção dos oceanos");
        // Registro de um usuário
        Voluntario usuario1 = new Voluntario(1, "João Silva", "joao@gmail.com", "usuario123", "comum");
        // Registro de um parceiro
        Parceiro parceiro1 = new Parceiro(1, "Pousada das Araras", "pousadaararas@contato.com", "parceiro123", 30, "ARARAS30%OFF");
        // ONG adiciona uma atividade
        Atividades atividade1 = new Atividades(1, "Limpeza de Praia", "Evento para limpar a praia do Leme", new Date(2024-1900, 06-1, 15), "09:00", "Praia do Leme", 50, "ecovoluntariado");
        ong1.adicionarAtividade(atividade1);
        // Usuário se inscreve na atividade
        Inscricao inscricao1 = new Inscricao(1, new Date(2024, 05, 10), usuario1, atividade1);

        // Função de simulação de inscrição e mandava pro banco de dados
        Inscricao.registrarInscricao(inscricao1, atividade1);

        Menu menu = new Menu();
        boolean isValid;

        //teste com todas classes, usando o Scanner
        System.out.println("\t\t\t\t\t\t\t\tOLÁ!!! BEM-VINDO(A) AO ECOWAVES. SE CADASTRE! ESCOLHA UMA OPÇÃO QUE VOCÊ SE ENCAIXE:\"");

        System.out.println("1- VOLUNTARIO | 2- ONG | 3- PARCEIRO");
        Scanner sc = new Scanner(System.in);
        String opcao1 = sc.next();
        if (!(isInteger(opcao1))) {
            do{
                System.out.println("Digite um valor numerico, por favor");
                opcao1 = sc.next();
            }while(!(isInteger(opcao1)));
        }
        int op1 = Integer.parseInt(opcao1);

        switch (op1) {
            case 1:
                sc.nextLine();
                System.out.print("Seu Nome: ");
                String nome = sc.nextLine();
                System.out.print("Email: ");
                String email = sc.next();
                if (!(validaEmail(email))) {
                    do{
                        System.out.println("O e-mail não está nos conformes. (Ex: emain@domain.com)");
                        System.out.print("Email: ");
                        email = sc.next();
                    }while((!validaEmail(email)));
                }
                System.out.print("Senha: ");
                String senha = sc.next();
                Voluntario usuario2 = new Voluntario(2, nome, email, senha, "comum");
                System.out.println("\t\t\t\t\t\t\t\t\t" + nome.toUpperCase() + ", você já está em nosso sistema. Escolha uma opção: ");

                int opcao2 = 0;

                do {
                    System.out.println("\n0 - Sair | 1- Portal ou ChatBot | 2 - EcoVoluntariado | 3- Seu Perfil | 4- Descontos dos Parceiros");
                    opcao2 = sc.nextInt();

                    switch (opcao2) {
                        case 0:
                            System.out.print(" ");
                            break;
                        case 1:
                            menu.exibirMenu();
                            break;
                        case 2:
                            System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\tAtividades que temos no momento:\n");
                            for (Atividades atividade : ong1.getAtividades()) {
                                System.out.println("Atividade: " + atividade.getNome_atividade() + ", Descrição: " + atividade.getDescricao_atividade() + ", Data: " + formatarData(atividade.getData()) + ", Vagas: " + atividade.getVagas());
                            }
                            System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t Deseja se inscrever? (1 - sim | 2 - não)");
                            String inscrever = sc.next();
                            if (inscrever.equals("1")) {
                                Inscricao inscricao2 = new Inscricao(1, new Date(), usuario2, atividade1);
                                Inscricao.registrarInscricao(inscricao2, atividade1);
                            } else if (inscrever.equals("2")){
                                System.out.println("OK!");
                            }else{
                                System.out.println("Não temos essa opção!");
                            }
                            break;
                        case 3:
                            usuario2.exibirPerfil();
                            break;
                        case 4:
                            System.out.println("\nNós temos parcerias com hoteis e pousadas, que fornecem descontos para nossos usuários!");
                            System.out.println("Basta copiar o código e colar na página de nosso parceiro. E você terá o desconto estipulado.");
                            parceiro1.vizualizarDesconto();
                            break;
                        default:
                            System.out.println("Essa opção não existe!!");
                            break;
                    }
                } while (opcao2 != 0);
                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t AGRADECEMOS POR USAR NOSSO SISTEMA, ATÉ A PRÓXIMA!");
                break;
            case 2:
                sc.nextLine();
                System.out.print("Razão Social: ");
                String razao_socialOng = sc.nextLine();
                System.out.print("Email: ");
                String emailOng = sc.next();
                if (!(validaEmail(emailOng))) {
                    do{
                        System.out.println("O e-mail não está nos conformes. (Ex: emain@domain.com)");
                        System.out.print("Email: ");
                        emailOng = sc.next();
                    }while((!validaEmail(emailOng)));
                }
                System.out.print("Senha: ");
                String senhaOng = sc.next();
                sc.nextLine();
                System.out.print("Uma breve descrição sobre sua ONG: ");
                String descricao = sc.nextLine();
                ONG ong2 = new ONG(2, razao_socialOng, emailOng, senhaOng, descricao);
                int opcao3 = 0;

                do {
                    System.out.println("\n0 - Sair | 1- Registrar uma Atividade | 2 - Ver suas Atividades | 3- Seu Perfil ");
                    opcao3 = sc.nextInt();
                    switch (opcao3) {
                        case 0:
                            System.out.print(" ");
                            break;
                        case 1:
                            sc.nextLine();
                            System.out.print("Nome da atividade: ");
                            String nome_atividade = sc.nextLine();
                            System.out.print("Descricao atividade: ");
                            String descricao_atividade = sc.nextLine();
                            System.out.print("Dia da atividade: ");

                            String d = sc.next();
                            if (!(isInteger(d))) {
                                do{
                                    System.out.println("Digite um valor numerico, por favor");
                                    System.out.print("Dia: ");
                                    d = sc.next();
                                }while(!(isInteger(d)));
                            }
                            int dia = Integer.parseInt(d);

                            if (dia < 0 || dia > 31) {
                                do {
                                    System.out.println("Hmm, esse dia não existe");
                                    System.out.print("Dia da atividade: ");
                                    dia = sc.nextInt();
                                } while (dia < 0 || dia > 31);
                            }

                            System.out.print("Mês da atividade: ");
                            String m = sc.next();
                            if (!(isInteger(m))) {
                                do{
                                    System.out.println("Digite um valor numerico, por favor");
                                    System.out.print("Mês: ");
                                    m = sc.next();
                                }while(!(isInteger(m)));
                            }
                            int mes = Integer.parseInt(m);

                            if (mes < 0 || mes > 12) {
                                do {
                                    System.out.println("Hmm, esse mês não existe");
                                    System.out.print("Mês da atividade: ");
                                    mes = sc.nextInt();
                                } while (mes < 0 || mes > 13);
                            }

                            System.out.print("Ano da atividade: ");
                            String a = sc.next();
                            if (!(isInteger(a))) {
                                do{
                                    System.out.println("Digite um valor numerico, por favor");
                                    System.out.print("Ano: ");
                                    a = sc.next();
                                }while(!(isInteger(a)));
                            }
                            int ano = Integer.parseInt(a);

                            if (ano < 2024 || ano > 2100) {
                                do {
                                    System.out.println("Hmm, esse ano já passou ou está muito distante");
                                    System.out.print("Ano da atividade: ");
                                    ano = sc.nextInt();
                                } while (ano < 2023 || ano > 3000);
                            }

                            System.out.print("Qual o horário? (XX:XX. Ex: 10:25)");
                            String hora = sc.next();
                            sc.nextLine();
                            System.out.print("Qual o local?");
                            String local = sc.nextLine();
                            System.out.print("Quantas vagas?");
                            int vagas = sc.nextInt();
                            System.out.print("Qual o tipo (ecovoluntariado ou ecoturismo)?");
                            String tipo = sc.next();
                            Atividades atividade2 = new Atividades(1, nome_atividade, descricao_atividade, new Date(ano-1900, mes-1, dia), hora, local, vagas, tipo);
                            ong2.adicionarAtividade(atividade2);
                            System.out.print("Atividade adicionada!");
                            break;
                        case 2:
                            if (ong2.getAtividades().isEmpty()) {
                                System.out.println("Não há atividades disponíveis no momento.");
                            } else {
                                System.out.println("\t\t\t\t\t\t\t\t\t\t\tSuas atividades:");
                                for (Atividades atividade : ong2.getAtividades()) {
                                    System.out.println("-> Atividade: " + atividade.getNome_atividade() + ", Descrição: " + atividade.getDescricao_atividade() + ", Data: " + formatarData(atividade.getData()) + ", Vagas: " + atividade.getVagas() + ", Tipo: " + atividade.getTipo());
                                }
                            }
                            break;
                        case 3:
                            ong2.exibirPerfil();
                            break;
                        default:
                            System.out.println("Essa opção não existe!!");
                            break;
                    }
                } while (opcao3 != 0);
                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t AGRADECEMOS POR USAR NOSSO SISTEMA, ATÉ A PRÓXIMA!");
                break;
            case 3:
                sc.nextLine();
                System.out.print("Razão Social: ");
                String razao_socialParceiro = sc.nextLine();
                System.out.print("Email: ");
                String emailParceiro = sc.next();
                if (!(validaEmail(emailParceiro))) {
                    do{
                        System.out.println("O e-mail não está nos conformes. (Ex: emain@domain.com)");
                        System.out.print("Email: ");
                        emailParceiro = sc.next();
                    }while((!validaEmail(emailParceiro)));
                }
                System.out.print("Senha: ");
                String senhaParceiro = sc.next();
                Parceiro parceiro2 = new Parceiro(2, razao_socialParceiro, emailParceiro, senhaParceiro);
                System.out.print("\t\t\t\t\t\t\t\t\t" + razao_socialParceiro.toUpperCase() + ", você já está em nosso sistema. Escolha uma opção: ");

                int opcao4 = 0;

                do {
                    System.out.println("\n0 - Sair | 1- Registrar um Desconto | 2 - Ver desconto | 3- Seu Perfil ");
                    opcao4 = sc.nextInt();
                    switch (opcao4) {
                        case 0:
                            System.out.println(" ");
                            break;
                        case 1:
                            System.out.print("Quanto % de desconto? (digite apenas numeros) ");
                            String desc = sc.next();
                            if (!(isInteger(desc))) {
                                do{
                                    System.out.println("Digite um valor numerico, por favor");
                                    System.out.print("Desconto: ");
                                    desc = sc.next();
                                }while(!(isInteger(desc)));
                            }
                            int desconto = Integer.parseInt(desc);

                            System.out.print("Qual será o código? (Sugestão: " + razao_socialParceiro.toUpperCase() + desconto + "%OFF) ");
                            String codigo = sc.next();
                            parceiro2.adicionarDesconto(desconto, codigo);
                            break;
                        case 2:
                            if (parceiro2.getDesconto() == 0) {
                                System.out.println("Ainda não foi registrado nenhum cupom.");
                            } else {
                                parceiro2.vizualizarDesconto();
                            }
                            break;
                        case 3:
                            parceiro2.exibirPerfil();
                            break;
                        default:
                            System.out.println("Essa opção não existe!");
                            break;
                    }
                } while (opcao4 != 0);
                break;
            default:
                System.out.println("ESSA OPÇÃO NÃO EXISTE");
                break;

        }
    }

//    metodos estaticos que podem ser usados em outras classes

    //esse método serve para formatar qualquer data no padrão do Brasil
    public static String formatarData(Date data){
        // Define o formato da data no padrão brasileiro
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        // Formata a data
        String dataFormatada = formatter.format(data);
        return dataFormatada;
    }

    public static boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    //esse método faz o padrão regex do e-mail
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    //esse método valida o e-mail que o usuário cadastra e retorna True se estiver dentro dos conformes do regex, senão estiver retorna False
    public static boolean validaEmail(String emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.matches();
    }
}
